package states;

import timer.Notifiable;
import timer.Timer;
import events.NumberButtonEvent;
import events.TimerRanOutEvent;
import events.TimerTickedEvent;

public class WarningState extends SecurityState implements Notifiable{
	private static WarningState instance;
    private Timer timer;
    private int redoPassword = 0;
    private int redoPasswordBreached = 0;
    private String code = "";
    private String codeBreached = "";
    
    /**
     * Private for the singleton pattern
     */
    private WarningState() {
    }

    /**
     * For singleton
     * 
     * @return the object
     */
    public static WarningState instance() {
        if (instance == null) {
            instance = new WarningState();
        }
        return instance;
    }
    
    @Override
   	public void handleEvent(NumberButtonEvent event, int number) {
    	if(timer.getTimeValue()!=0) {
    		code += number;
    		if(code.equals("1234")) {
    			redoPassword = 0;
    			if(!SecurityContext.instance().testReady()) {
    	    		System.out.println("NotReadyState");
    	    		code = "";
    	    		SecurityContext.instance().changeState(NotReadyState.instance());
    	    	}
    	    	else {
    	    		System.out.println("ReadyState");
    	    		code = "";
    	    		SecurityContext.instance().changeState(ReadyState.instance());
    	    	}
    		}
    		if(code.length() == 4 && !code.equals("1234")) {
    			redoPassword++;
    			SecurityContext.instance().showWarningTimeLeft(timer.getTimeValue(), redoPassword);
    			code = "";
    		}
    	}
    	else {
    		codeBreached += number;
    		if(codeBreached.equals("1234")) {
    			redoPasswordBreached = 0;
    			if(!SecurityContext.instance().testReady()) {
    	    		System.out.println("NotReadyState");
    	    		codeBreached = "";
    	    		SecurityContext.instance().changeState(NotReadyState.instance());
    	    	}
    	    	else {
    	    		System.out.println("ReadyState");
    	    		codeBreached = "";
    	    		SecurityContext.instance().changeState(ReadyState.instance());
    	    	}
    		}
    		if(codeBreached.length() == 4 && !codeBreached.equals("1234")) {
    			redoPasswordBreached++;
    			SecurityContext.instance().showPasscodeStayRedo(redoPasswordBreached);
    			codeBreached = "";
    		}
    	}
    }
    
    @Override
    public void handleEvent(TimerTickedEvent event) {
        SecurityContext.instance().showWarningTimeLeft(timer.getTimeValue(), redoPassword);
    }

    /**
     * Process the timer runs out event
     */
    @Override
    public void handleEvent(TimerRanOutEvent event) {
    	redoPassword = 0;
    	SecurityContext.instance().showWarningTimeLeft(0);
    }
    
	@Override
	public void enter() {
		timer = new Timer(this, 15);
        SecurityContext.instance().showWarningTimeLeft(timer.getTimeValue(), redoPassword);
		
	}
	@Override
	public void leave() {
		timer.stop();
        timer = null;	
	}
}
