package application;
	

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.geometry.Pos;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			Pane pane = new Pane();
			Scene scene = new Scene(pane,700,300);
			primaryStage.setTitle("Security System");
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			Image icon = new Image(getClass().getResourceAsStream("/images/Camera.png"));			
			primaryStage.getIcons().add(icon);
			
			TextField text = new TextField();
			text.setPrefWidth(520);
			text.setPrefHeight(150);
			text.setLayoutX(150);
			text.setLayoutY(20);
			text.setPromptText("Ready");
			text.setFocusTraversable(false);
			text.setAlignment(Pos.TOP_LEFT);
			
			Button button1 = new Button("1");
			button1.setLayoutX(30);
			button1.setLayoutY(20);
			button1.setPrefWidth(30);
			button1.setPrefHeight(30);
			
			Button button2 = new Button("2");
			button2.setLayoutX(60);
			button2.setLayoutY(20);
			button2.setPrefWidth(30);
			button2.setPrefHeight(30);
			
			Button button3 = new Button("3");
			button3.setLayoutX(90);
			button3.setLayoutY(20);
			button3.setPrefWidth(30);
			button3.setPrefHeight(30);
			
			Button button4 = new Button("4");
			button4.setLayoutX(30);
			button4.setLayoutY(50);
			button4.setPrefWidth(30);
			button4.setPrefHeight(30);
			
			Button button5 = new Button("5");
			button5.setLayoutX(60);
			button5.setLayoutY(50);
			button5.setPrefWidth(30);
			button5.setPrefHeight(30);
			
			Button button6 = new Button("6");
			button6.setLayoutX(90);
			button6.setLayoutY(50);
			button6.setPrefWidth(30);
			button6.setPrefHeight(30);
			
			Button button7 = new Button("7");
			button7.setLayoutX(30);
			button7.setLayoutY(80);
			button7.setPrefWidth(30);
			button7.setPrefHeight(30);
			
			Button button8 = new Button("8");
			button8.setLayoutX(60);
			button8.setLayoutY(80);
			button8.setPrefWidth(30);
			button8.setPrefHeight(30);
			
			Button button9 = new Button("9");
			button9.setLayoutX(90);
			button9.setLayoutY(80);
			button9.setPrefWidth(30);
			button9.setPrefHeight(30);
			
			Button button0 = new Button("0");
			button0.setLayoutX(60);
			button0.setLayoutY(110);
			button0.setPrefWidth(30);
			button0.setPrefHeight(30);
			
			CheckBox zone1 = new CheckBox("Zone 1");
			zone1.setLayoutX(30);
			zone1.setLayoutY(200);
			
			CheckBox zone2 = new CheckBox("Zone 2");
			zone2.setLayoutX(100);
			zone2.setLayoutY(200);
			
			CheckBox zone3 = new CheckBox("Zone 3");
			zone3.setLayoutX(170);
			zone3.setLayoutY(200);
			
			Label readyStatus = new Label("Ready Status");
			readyStatus.setLayoutX(110);
			readyStatus.setLayoutY(230);
			
			Button motionDetector = new Button("Motion Detector");
			motionDetector.setLayoutX(85);
			motionDetector.setLayoutY(250);
			motionDetector.setPrefWidth(120);
			
			Button stay = new Button("Stay");
			stay.setLayoutX(350);
			stay.setLayoutY(200);
			stay.setPrefWidth(60);
			
			Button away = new Button("Away");
			away.setLayoutX(420);
			away.setLayoutY(200);
			away.setPrefWidth(60);
			
			Button cancel = new Button("Cancel");
			cancel.setLayoutX(490);
			cancel.setLayoutY(200);
			cancel.setPrefWidth(60);
	
			pane.getChildren().addAll(text,button1,button2,button3,button4,button5,button6,button7,button8,button9,button0,zone1,zone2,zone3
					,readyStatus,motionDetector,stay,away,cancel);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
